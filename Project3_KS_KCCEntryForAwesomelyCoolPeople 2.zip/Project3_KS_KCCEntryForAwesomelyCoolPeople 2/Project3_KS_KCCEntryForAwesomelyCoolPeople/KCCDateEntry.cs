﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3_KS_KCCEntryForAwesomelyCoolPeople
{
    public partial class KCCDataEntryForm : Form
    {
        public KCCDataEntryForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            prospectsLabel.Text = "";
            seniorRadioButton.Checked = false;
            juniorRadioButton.Checked = false;
            sophomoreRadioButton.Checked = false;
            freshmanRadioButton.Checked = false;
            studentNameTextBox.Clear();
            creditsMaskedTextBox.Clear();
            highSchoolComboBox.SelectedIndex = -1;
            majorComboBox.SelectedIndex = -1;
            entryListBox.Items.Clear();
            studentNameTextBox.Focus();
        }

        private void KCCDataEntryForm_Load(object sender, EventArgs e)
        {
            entryListBox.Items.Add("Student:" + "\t\t" + "High School:" + "\t\t" + "Major:" + "\t\t" + "Class:" + "\t\t" + "Credits:");
            studentNameTextBox.Focus();
        }

        private void highSchoolButton_Click(object sender, EventArgs e)
        {
            string student = studentNameTextBox.Text;

            if (string.IsNullOrWhiteSpace(student))
            {
                entryErrorProvider.SetError(studentNameTextBox, "Input your name.");
                return;
            }
            else
            {
                entryErrorProvider.SetError(studentNameTextBox, "");
            }

            
            string highSchoolAttended = highSchoolComboBox.Text;

            if (string.IsNullOrWhiteSpace(highSchoolAttended))
            {
                entryErrorProvider.SetError(highSchoolComboBox, "");
                return;
            }
            

            if (highSchoolComboBox.Items.Contains(highSchoolAttended))
            {
                entryErrorProvider.SetError(highSchoolComboBox, "High School already exists.");
                return;
            }
            else
            {
                entryErrorProvider.SetError(highSchoolComboBox, "");
            }

            highSchoolComboBox.Items.Add(highSchoolAttended);

            studentNameTextBox.Focus();
            studentNameTextBox.SelectAll();
        }

        private void studentNameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(studentNameTextBox.Text))
            {
                entryErrorProvider.SetError(studentNameTextBox, "");
            }
        }

        private void saveStudentButton_Click(object sender, EventArgs e)
        {
            string student = studentNameTextBox.Text;
            int credits = 0;
            string sClass;

            if (!int.TryParse(creditsMaskedTextBox.Text, out credits) || credits < 0)
            {
                entryErrorProvider.SetError(creditsMaskedTextBox, "Input credits completed");
                creditsMaskedTextBox.Focus();
            }

            if (string.IsNullOrWhiteSpace(student))
            {
                entryErrorProvider.SetError(entryListBox, "Input your name.");
                return;
            }
            else
            {
                entryErrorProvider.SetError(entryListBox, "");
            }

            string highSchoolAttended = highSchoolComboBox.Text;
            string majorIntended = majorComboBox.Text;

            if (string.IsNullOrWhiteSpace(highSchoolAttended))
            {
                entryErrorProvider.SetError(highSchoolComboBox, "");
                return;
            }

            if (string.IsNullOrWhiteSpace(majorIntended))
            {
                entryErrorProvider.SetError(majorComboBox, "");
                return;
            }

            if (freshmanRadioButton.Checked)
            {
                sClass = "Fr.";
            }
            else if (sophomoreRadioButton.Checked)
            {
                sClass = "So.";
            }
            else if (juniorRadioButton.Checked)
            {
                sClass = "Jr.";
            }
            else
            {
                sClass = "Sr.";
            }
            //if (seniorRadioButton.Checked)
            //{
            //    sClass = "Sr.";
            //}

            

            entryListBox.Items.Add(student + "\t\t" + highSchoolAttended + "\t\t" + majorIntended + "\t\t" + sClass + "\t\t" + credits);
            
            //yay i have solvedd the problem


            studentNameTextBox.Focus();
            studentNameTextBox.SelectAll();
        }

        private void majorButton_Click(object sender, EventArgs e)
        {
            string student = studentNameTextBox.Text;

            if (string.IsNullOrWhiteSpace(student))
            {
                entryErrorProvider.SetError(studentNameTextBox, "Input your name.");
                return;
            }
            else
            {
                entryErrorProvider.SetError(studentNameTextBox, "");
            }


            string majorIntended = majorComboBox.Text;

            if (string.IsNullOrWhiteSpace(majorIntended))
            {
                entryErrorProvider.SetError(majorComboBox, "");
                return;
            }


            if (majorComboBox.Items.Contains(majorIntended))
            {
                entryErrorProvider.SetError(majorComboBox, "Major already exists.");
                return;
            }
            else
            {
                entryErrorProvider.SetError(majorComboBox, "");
            }

            majorComboBox.Items.Add(majorIntended);

            studentNameTextBox.Focus();
            studentNameTextBox.SelectAll();
        }

        private void creditsMaskedTextBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            int credits = 0;

            if (!int.TryParse(creditsMaskedTextBox.Text, out credits)|| credits < 0)
            {
                entryErrorProvider.SetError(creditsMaskedTextBox, "Input credits completed");
                creditsMaskedTextBox.Focus();
            }
        }

        private void removeHighSchoolButton_Click(object sender, EventArgs e)
        {
            if (highSchoolComboBox.SelectedIndex >= 0)
            {
                highSchoolComboBox.Items.RemoveAt(highSchoolComboBox.SelectedIndex);
            }
        }

        private void removeMajorButton_Click(object sender, EventArgs e)
        {
            if (majorComboBox.SelectedIndex >= 0)
            {
                majorComboBox.Items.RemoveAt(majorComboBox.SelectedIndex);
            }
        }

        private void deleteRecordsButton_Click(object sender, EventArgs e)
        {
            if (entryListBox.SelectedIndex >= 0)
            {
                entryListBox.Items.RemoveAt(entryListBox.SelectedIndex);
            }
        }
    }
}
